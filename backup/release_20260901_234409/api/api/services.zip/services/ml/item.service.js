const pictureService = require("./picture.service");

exports.build = async (product, pictures, accessToken) => {

    const uploadedPictures = await pictureService.upload(

        pictures.map(p => ({
            source: p.original_url || p.source || p.path,
            path: p.path
        })),

        accessToken

    );

    if (!uploadedPictures.length) {
        throw new Error("Nenhuma imagem válida foi enviada.");
    }

    const attributes = [];

    if (product.brand) {
        attributes.push({
            id: "BRAND",
            value_name: product.brand
        });
    }

    if (product.model) {
        attributes.push({
            id: "MODEL",
            value_name: product.model
        });
    }

    // Produto sem GTIN
    attributes.push({
        id: "EMPTY_GTIN_REASON",
        value_id: "17055160"
    });

    return {

        title: product.title,

        category_id: product.ml_category_id,

        price: Number(product.sale_price),

        currency_id: "BRL",

        available_quantity: Number(product.quantity || 1),

        buying_mode: "buy_it_now",

        listing_type_id:
            product.ml_listing_type || "gold_special",

        condition:
            (product.condition || "used").toLowerCase(),

        pictures: uploadedPictures,

        attributes,

        accepts_mercadopago: true,

        warranty:
            product.warranty || "Sem garantia"

    };

};