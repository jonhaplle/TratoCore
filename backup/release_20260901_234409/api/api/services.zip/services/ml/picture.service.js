const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");

const API = "https://api.mercadolibre.com";

exports.upload = async (pictures, accessToken) => {

    console.log("==================================");
    console.log("UPLOAD MERCADO LIVRE");
    console.log("==================================");

    if (!Array.isArray(pictures) || pictures.length === 0) {
        return [];
    }

    const uploaded = [];

    for (const picture of pictures) {

        try {

            // Se já existe URL pública, usa diretamente
            if (
                picture.source &&
                (picture.source.startsWith("http://") ||
                 picture.source.startsWith("https://"))
            ) {

                uploaded.push({
                    source: picture.source
                });

                continue;
            }

            // Upload de arquivo local
            const form = new FormData();

            form.append(
                "file",
                fs.createReadStream(picture.path || picture.source)
            );

            const response = await axios.post(
                `${API}/pictures/items/upload`,
                form,
                {
                    headers: {
                        Authorization: `Bearer ${accessToken}`,
                        ...form.getHeaders()
                    },
                    maxBodyLength: Infinity,
                    maxContentLength: Infinity
                }
            );

            uploaded.push({
                id: response.data.id
            });

        } catch (err) {

            console.error("Erro upload imagem:");

            if (err.response) {
                console.error(err.response.data);
            } else {
                console.error(err.message);
            }

            throw err;
        }

    }

    return uploaded;

};