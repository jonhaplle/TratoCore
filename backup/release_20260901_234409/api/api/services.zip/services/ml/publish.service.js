console.log("### NOVO PUBLISH SERVICE EXECUTADO ###");

const productService = require("../productService");
const productImageService = require("../productImageService");
const itemService = require("./item.service");
const apiService = require("./api.service");
const mlProductService = require("./mlProduct.service");

module.exports.publish = async (productId) => {

    const product = await productService.getById(productId);

    if (!product)
        throw new Error("Produto não encontrado.");

    const pictures = await productImageService.getByProductId(productId);

    if (!pictures.length)
        throw new Error("O produto não possui imagens.");

    // Recupera o token uma única vez
    const accessToken = await apiService.getAccessToken();

    // Monta o payload do anúncio
    const item = await itemService.build(
        product,
        pictures,
        accessToken
    );

    // Publica o anúncio
    const mlResponse = await apiService.publishItem(item);

    // Cria a descrição separadamente
    if (product.description && product.description.trim() !== "") {

        await apiService.createDescription(
            mlResponse.id,
            product.description
        );

    }

    await mlProductService.savePublication(
        productId,
        mlResponse
    );

    return {
        success: true,
        ml: mlResponse,
        item
    };

};