﻿const axios = require("axios");

const API = "https://api.mercadolibre.com";

let accessToken = null;

exports.setAccessToken = (token) => {
    accessToken = token;
};

exports.getAccessToken = async () => {

    if (!accessToken) {
        throw new Error("Access Token não configurado.");
    }

    return accessToken;
};

exports.publishItem = async (item) => {

    const token = await exports.getAccessToken();

    const response = await axios.post(
        `${API}/items`,
        item,
        {
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            }
        }
    );

    return response.data;
};

exports.createDescription = async (itemId, description) => {

    const token = await exports.getAccessToken();

    await axios.post(
        `${API}/items/${itemId}/description`,
        {
            plain_text: description
        },
        {
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            }
        }
    );
};

exports.getItem = async (itemId) => {

    const token = await exports.getAccessToken();

    const response = await axios.get(
        `${API}/items/${itemId}`,
        {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }
    );

    return response.data;
};

exports.updateItem = async (itemId, body) => {

    const token = await exports.getAccessToken();

    const response = await axios.put(
        `${API}/items/${itemId}`,
        body,
        {
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            }
        }
    );

    return response.data;
};