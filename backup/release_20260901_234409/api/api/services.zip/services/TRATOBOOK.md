# TRATOBOOK
## Cérebro Oficial do Projeto TratoCore

Versão: 1.1
Última atualização: 06/08/2026

Projeto criado por:
Marco Aurélio Silva

Desenvolvimento:
ChatGPT

Status:
EM DESENVOLVIMENTO ATIVO

---

# MISSÃO DO PROJETO

Criar uma plataforma capaz de transformar uma ou mais fotos em anúncios completos publicados automaticamente em marketplaces.

MVP:

OpenAI Vision

↓

Mercado Livre

Depois:

Shopee

OLX

Facebook Marketplace

Amazon

Magalu

---

# OBJETIVO PRINCIPAL

Fluxo ideal

Foto

↓

Upload

↓

OpenAI Vision

↓

Identificação do produto

↓

Título

↓

Descrição

↓

Categoria

↓

Preço

↓

Atributos

↓

JSON Mercado Livre

↓

Anúncio publicado

---

# FILOSOFIA

Nunca reescrever.

Sempre evoluir.

Commits pequenos.

Software funcionando ao final de cada missão.

Trabalhar sobre código existente.

---

# DIRETÓRIO

C:\TratoCore

---

# STACK

Node.js

Express

PostgreSQL

OpenAI

Mercado Livre OAuth

Axios

Sharp

Multer

Git

---

# BANCO

products

product_images

oauth

ml_products

---

# ARQUITETURA

Produto

↓

Imagem

↓

OpenAI

↓

JSON

↓

item.service

↓

publish.service

↓

api.service

↓

Mercado Livre

---

# COMPONENTES AUDITADOS

## mlController.js

STATUS

OK

Não alterar.

---

## publish.service.js

STATUS

OK

Fluxo aprovado.

Não alterar.

---

## api.service.js

STATUS

OK

Implementado:

OAuth

Refresh Token

Publicação

Renovação automática

Não alterar.

---

## productService.js

STATUS

OK

CRUD aprovado.

---

## item.service.js

STATUS

OK

Responsável por montar o payload enviado ao Mercado Livre.

Melhorias futuras:

Atributos automáticos

Categorias automáticas

---

## picture.service.js

STATUS

MOCK

É o único módulo crítico restante.

Deve substituir TEMP_1/TEMP_2 por imagens reais.

---

# DESCOBERTAS IMPORTANTES

## Storage

Confirmado.

As imagens são gravadas em:

C:\TratoCore\storage

Estrutura:

storage/

originals/

thumbs/

products/

temp/

---

## Express Static

Confirmado.

app.use("/storage", express.static(storagePath));

Funcionando corretamente.

---

## Teste realizado

URL local validada:

http://localhost:3000/storage/originals/arquivo.png

Resultado:

Imagem carregada corretamente.

Portanto:

Express OK

Storage OK

Multer OK

Sharp OK

---

# GARGALO ATUAL

As imagens estão acessíveis apenas por:

http://localhost:3000

O Mercado Livre não consegue acessar localhost.

É necessário fornecer URLs HTTPS públicas.

---

# SOLUÇÃO APROVADA

Durante desenvolvimento:

Utilizar túnel HTTPS.

Opções:

ngrok

Cloudflare Tunnel

Em produção:

Domínio próprio HTTPS.

---

# picture.service.js

Objetivo:

Receber:

/storage/originals/arquivo.png

Converter automaticamente para:

https://PUBLIC_BASE_URL/storage/originals/arquivo.png

Retornar:

[
    {
        source: "https://..."
    }
]

Sem alterar:

publish.service.js

api.service.js

Controllers

Rotas

---

# DECISÕES APROVADAS

Não utilizar Cloudinary.

Não criar novos Controllers.

Não criar novas Rotas.

Não alterar api.service.js.

Não alterar publish.service.js.

Reaproveitar toda arquitetura existente.

Sempre seguir documentação oficial do Mercado Livre.

---

# BACKLOG

PRIORIDADE MÁXIMA

✔ Storage validado

✔ Express validado

✔ Fluxo de upload validado

⬜ Atualizar ngrok

⬜ Configurar PUBLIC_BASE_URL

⬜ Implementar picture.service.js

⬜ Primeiro anúncio Mercado Livre

⬜ Corrigir erros retornados pela API

⬜ IA gerar atributos

⬜ IA escolher categoria

⬜ Publicação em lote

⬜ Shopee

⬜ Demais Marketplaces

---

# CHECKLIST

Antes de publicar

[ ] PostgreSQL

[ ] API

[ ] OAuth

[ ] Token válido

[ ] URL HTTPS pública

[ ] OpenAI

[ ] Último commit

[ ] Backup

---

# NUNCA FAZER

Inventar endpoints da API do Mercado Livre.

Duplicar código.

Criar infraestrutura desnecessária.

Modificar módulos aprovados.

Alterar arquitetura sem necessidade.

---

# ROADMAP

FASE 1

Foto

↓

IA

↓

Mercado Livre

↓

Publicado

====================

FASE 2

Categorias automáticas

====================

FASE 3

Atributos automáticos

====================

FASE 4

Lote de anúncios

====================

FASE 5

Shopee

====================

FASE 6

Demais marketplaces

---

# ESTADO ATUAL

Projeto aproximadamente 97% concluído.

Infraestrutura validada.

Storage funcionando.

Express funcionando.

Upload funcionando.

Maior bloqueio:

Disponibilizar imagens por HTTPS público para que o Mercado Livre possa acessá-las e concluir a publicação do primeiro anúncio.

---

# COMO RETOMAR

Ao iniciar uma nova conversa:

Enviar este TRATOBOOK.

Dizer:

"Continue exatamente da última missão."

O desenvolvimento deve continuar do ponto atual, preservando todas as decisões registradas e evitando reanálise da arquitetura.