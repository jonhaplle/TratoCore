const apiService = require("./ml/api.service");
const catalogMatcher = require("./ml/catalogMatcher.service");

function clean(value) {
    if (value === undefined || value === null) return "";
    return String(value).trim();
}

function normalizeText(value) {
    return clean(value)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase();
}

function normalizeCandidates(data) {
    const raw = Array.isArray(data)
        ? data
        : Array.isArray(data?.results)
            ? data.results
            : [];

    return raw
        .map(item => ({
            ...item,
            name: clean(item.name || item.title),
            attributes: Array.isArray(item.attributes)
                ? item.attributes
                : []
        }))
        .filter(item => item.name);
}

async function findCatalogMatch(identification) {

    const id = identification || {};

    const terms = Array.isArray(id.search_terms)
        ? id.search_terms.filter(Boolean)
        : [
            id.brand,
            id.line,
            id.model,
            id.generation,
            id.product_type
        ].filter(Boolean);

    const queries = [
        ...new Set(
            terms
                .map(clean)
                .filter(Boolean)
        )
    ].slice(0, 3);

    const all = new Map();

    for (const q of queries) {

        try {

            const params = {
                q,
                limit: 20
            };

            // Para consoles, restringe a busca ao dominio de consoles.
            // Isso reduz jogos/acessorios antes mesmo do matcher.
            if (normalizeText(id.product_type) === "console") {
                params.domain_id = "MLB-GAME_CONSOLES";
            }

            const data = await apiService.searchProducts(params);

            for (const candidate of normalizeCandidates(data)) {

                const key = candidate.id || candidate.name;

                if (!all.has(key)) {
                    all.set(key, candidate);
                }
            }

        } catch (err) {

            console.warn(
                "Catalog search failed for:",
                q,
                err.message
            );
        }
    }

    const candidates = Array.from(all.values());

    if (!candidates.length) {

        return {
            found: false,
            confidence: "LOW",
            best: null,
            ranked: [],
            candidates_received: 0,
            candidates_removed_as_incompatible: 0
        };
    }

    const result = catalogMatcher.findBestCatalogProduct({
        candidates,
        identified: id
    });

    return {
        // Só existe correspondência quando o matcher considera o candidato seguro.
        found: Boolean(result.best),
        confidence: result.confidence,
        best: result.best,
        ranked: result.ranked.slice(0, 10),
        candidates_received: result.candidates_received,
        candidates_removed_as_incompatible:
            result.candidates_removed_as_incompatible,
        safe_candidates: result.safe_candidates || 0
    };
}

module.exports = {
    findCatalogMatch
};